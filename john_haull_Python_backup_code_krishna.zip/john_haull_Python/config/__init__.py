from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager
from config.settings import DevelopmentConfig
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView
from flask_jwt_extended import JWTManager
from flask_mail import Mail
import redis

db = SQLAlchemy()
bcrypt = Bcrypt()
login_manager = LoginManager()
login_manager.login_view = 'users.login'
login_manager.login_message_category = 'info'
jwt = JWTManager()
mail = Mail()
revoked_tokens = set()


def create_app(config_class=DevelopmentConfig):
    from src.models.users import User, UserProfile
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)
    bcrypt.init_app(app)
    login_manager.init_app(app)
    jwt.init_app(app)
    mail.init_app(app)


    # Initialize Flask-Admin
    admin = Admin(app, name='John-Haull', template_mode='bootstrap3')

    # Add views for User and UserProfile
    admin.add_view(ModelView(User, db.session))
    admin.add_view(ModelView(UserProfile, db.session))

    from src.views.users import users as users_blueprint
    app.register_blueprint(users_blueprint)
    # app.register_blueprint(users_blueprint,url_prefix='/users')
    
    from src.views.vendors import vendors as vendors_blueprint
    app.register_blueprint(vendors_blueprint)

    return app


@jwt.token_in_blocklist_loader
def check_if_token_revoked(jwt_header, jwt_payload):
    jti = jwt_payload["jti"]
    return jti in revoked_tokens


@login_manager.user_loader
def load_user(id):
    from src.models.users import User
    return User.query.get(int(id))
