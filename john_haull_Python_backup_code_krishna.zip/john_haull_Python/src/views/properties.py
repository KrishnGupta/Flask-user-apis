from config import db
from datetime import datetime
from flask_login import current_user
# from src.views.forms import PropertyForm
from flask import Blueprint, request, jsonify
from src.models.properties import Property, Portfolio

properties = Blueprint('properties', __name__)

@properties.route('/all_properties', methods=['GET'])
def get_all_properties():
    try:
        properties = Property.query.all()
        property_list = []
        for property in properties:
            property_data = {
                'id': property.id,
                'address': property.address,
                'user_id': property.user_id,  
                'created_at': property.created_at,
                'modified_at': property.modified_at
            }
            property_list.append(property_data)

        return jsonify(property_list), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@properties.route('/properties/<int:property_id>', methods=['GET'])
def get_property(property_id):
    try:
        property = Property.query.filter_by(id=property_id, user_id=current_user.id).first_or_404()
        
        property_data = {
            'id': property.id,
            'address': property.address,
            'created_at': property.created_at,
            'modified_at': property.modified_at
        }
        
        return jsonify(property_data), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@properties.route('/create_property', methods=['POST'])
def create_property():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No input data provided'}), 400

        form = PropertyForm(data=data)

        if form.validate():
            property = Property(
                address=form.address.data,
                user_id=2
            )
            db.session.add(property)
            db.session.commit()

            return jsonify({'message': 'Property has registered successfully'}), 201
        else:
            return jsonify({'errors': form.errors}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500
    
@properties.route('/property/<int:id>', methods=['PUT'])
def update_property(id):
    try:
        property = Property.query.get(id)
        if not property:
            return jsonify({'error': 'Property not found'}), 404

        data = request.json

        address = data.get('address')
        is_active = data.get('is_active')
        is_open = data.get('is_open')

        if address is not None:
            if len(address) > 255:
                return jsonify({'error': 'Address cannot exceed 255 characters'}), 400
            property.address = address

        if is_active is not None:
            if not isinstance(is_active, bool):
                return jsonify({'error': 'Invalid value for is_active'}), 400
            property.is_active = is_active

        if is_open is not None:
            if not isinstance(is_open, bool):
                return jsonify({'error': 'Invalid value for is_open'}), 400
            property.is_open = is_open

        property.modified_at = datetime.utcnow()

        db.session.commit()

        property_data = {
            'id': property.id,
            'address': property.address,
            'user_id': property.user_id,
            'is_active': property.is_active,
            'is_open': property.is_open,
            'created_at': property.created_at,
            'modified_at': property.modified_at
        }

        return jsonify(property_data), 200

    except Exception as e:
        properties.logger.error(f'Error updating property with id {id}: {e}')
        
        return jsonify({'error': 'An unexpected error occurred'}), 500


@properties.route('/property/<int:id>', methods=['DELETE'])
def delete_property(id):
    try:
        property = Property.query.get(id)
        if not property:
            return jsonify({'error': 'Property not found'}), 404

        portfolio_count = Portfolio.query.filter_by(property_id=id).count()
        if portfolio_count > 0:
            return jsonify({'error': 'Property is referenced in portfolio and cannot be deleted'}), 400

        db.session.delete(property)
        db.session.commit()

        return jsonify({'message': f'Property with id {id} has been deleted'}), 200

    except Exception as e:
        properties.logger.error(f'Error deleting property with id {id}: {e}')
        
        return jsonify({'error': 'An unexpected error occurred'}), 500

@properties.route('/portfolios', methods=['GET'])
def get_all_portfolios():
    portfolios = Portfolio.query.all()
    portfolio_list = []
    for portfolio in portfolios:
        portfolio_list.append({
            'id': portfolio.id,
            'user_id': portfolio.user_id,
            'vendor_id': portfolio.vendor_id,
            'property_id': portfolio.property_id,
            'is_active': portfolio.is_active,
            'created_at': portfolio.created_at,
            'modified_at': portfolio.modified_at
        })
    return jsonify(portfolio_list)

@properties.route('/portfolio/<int:id>', methods=['GET'])
def get_portfolio_by_id(id):
    portfolio = Portfolio.query.get(id)
    if not portfolio:
        return jsonify({'error': 'Portfolio not found'}), 404

    return jsonify({
        'id': portfolio.id,
        'user_id': portfolio.user_id,
        'vendor_id': portfolio.vendor_id,
        'property_id': portfolio.property_id,
        'is_active': portfolio.is_active,
        'created_at': portfolio.created_at,
        'modified_at': portfolio.modified_at
    })

@properties.route('/create_portfolio', methods=['POST'])
def create_portfolio():
    data = request.json
    user_id = data.get('user_id')
    property_ids = data.get('property_ids')
    vendor_ids = data.get('vendor_ids')
    
    if not user_id or not property_ids or not vendor_ids:
        return jsonify({'error': 'user_id, property_ids, and vendor_ids are required'}), 400

    portfolios = []
    for property_id in property_ids:
        for vendor_id in vendor_ids:
            new_portfolio = Portfolio(
                user_id=user_id,
                property_id=property_id,
                vendor_id=vendor_id,
                is_active=True
            )
            db.session.add(new_portfolio)
            portfolios.append(new_portfolio)
    
    db.session.commit()

    return jsonify([portfolio.id for portfolio in portfolios]), 201


@properties.route('/portfolio/<int:id>', methods=['PUT'])
def update_portfolio(id):
    try:
        portfolio = Portfolio.query.get(id)
        if not portfolio:
            return jsonify({'error': 'Portfolio not found'}), 404

        data = request.json

        user_id = data.get('user_id')
        vendor_id = data.get('vendor_id')
        property_id = data.get('property_id')
        is_active = data.get('is_active')

        if user_id is not None:
            if not isinstance(user_id, int):
                return jsonify({'error': 'Invalid value for user_id'}), 400

        if vendor_id is not None:
            if not isinstance(vendor_id, int):
                return jsonify({'error': 'Invalid value for vendor_id'}), 400

        if property_id is not None:
            if not isinstance(property_id, int):
                return jsonify({'error': 'Invalid value for property_id'}), 400

        if is_active is not None:
            if not isinstance(is_active, bool):
                return jsonify({'error': 'Invalid value for is_active'}), 400
            portfolio.is_active = is_active

        if user_id is not None:
            portfolio.user_id = user_id
        if vendor_id is not None:
            portfolio.vendor_id = vendor_id
        if property_id is not None:
            portfolio.property_id = property_id

        portfolio.modified_at = datetime.utcnow()

        db.session.commit()

        portfolio_data = {
            'id': portfolio.id,
            'user_id': portfolio.user_id,
            'vendor_id': portfolio.vendor_id,
            'property_id': portfolio.property_id,
            'is_active': portfolio.is_active,
            'created_at': portfolio.created_at,
            'modified_at': portfolio.modified_at
        }

        return jsonify(portfolio_data), 200

    except Exception as e:
        properties.logger.error(f'Error updating portfolio with id {id}: {e}')
        
        return jsonify({'error': 'An unexpected error occurred'}), 500

@properties.route('/portfolio/<int:id>', methods=['DELETE'])
def delete_portfolio(id):
    try:
        portfolio = Portfolio.query.get(id)
        if not portfolio:
            return jsonify({'error': 'Portfolio not found'}), 404

        db.session.delete(portfolio)
        db.session.commit()

        return jsonify({'message': f'Portfolio with id {id} has been deleted'}), 200

    except Exception as e:
        properties.logger.error(f'Error deleting portfolio with id {id}: {e}')
        
        return jsonify({'error': 'An unexpected error occurred'}), 500