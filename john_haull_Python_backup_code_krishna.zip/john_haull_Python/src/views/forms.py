from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField,SelectField,FileField
from wtforms.validators import DataRequired, Length, Email, EqualTo,Optional
from flask_wtf.file import FileAllowed


class RegistrationForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    first_name = StringField('First Name', validators=[DataRequired()])
    last_name = StringField('Last Name', validators=[DataRequired()])
    contact_no = StringField('Contact Number', validators=[DataRequired()])
    role = SelectField('Role', choices=[('one time', 'One Time'), ('admin', 'Admin'), ('enterprise', 'Enterprise')], default='one time')
    profile_image = FileField('Profile Image',validators=[Optional()])
    submit = SubmitField('Sign Up')

    
class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    submit = SubmitField('Login')


class ChangePasswordForm(FlaskForm):
    current_password = PasswordField('Current Password', validators=[DataRequired()])
    new_password = PasswordField('New Password', validators=[DataRequired(), Length(min=6)])
    confirm_new_password = PasswordField('Confirm New Password', validators=[DataRequired(), EqualTo('new_password')])
    submit = SubmitField('Change Password')


class UpdateUserForm(FlaskForm):
    first_name = StringField('First Name', validators=[Optional()])
    last_name = StringField('Last Name', validators=[Optional()])
    contact_no = StringField('Contact Number', validators=[Optional(), Length(min=10, max=15)])
    submit = SubmitField('Update')
