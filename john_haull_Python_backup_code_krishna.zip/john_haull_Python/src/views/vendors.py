from config import db
from datetime import datetime
from src.models.vendors import Vendor
from src.views.properties import Portfolio
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity,get_jwt
from http import HTTPStatus
from src.controller.users_controller import *


vendors = Blueprint('vendors', __name__)


@vendors.route('/create_vendor', methods=['POST'])
@jwt_required()
def create_vendor():
    response = generate_response()
    try:
        current_user = get_jwt_identity()
        if not current_user:
            response = generate_response(
                status=HTTPStatus.UNAUTHORIZED,
                message='Authentication required.'
            )
            return response, HTTPStatus.UNAUTHORIZED
        
        # Check if the current user has an admin role
        user_role = current_user.get('role')
        if user_role != 'admin':
            response = generate_response(
                status=HTTPStatus.FORBIDDEN,
                message='You do not have permission to access this resource.'
            )
            return response, HTTPStatus.FORBIDDEN
        
        data = request.get_json()
        
        # Check for missing data
        if not data or 'name' not in data:
            response = generate_response(
                status=HTTPStatus.BAD_REQUEST,
                message='Name is required.'
            )
            return response, HTTPStatus.BAD_REQUEST
        
        name = data.get('name')
        email = data.get('email')

        # Validate the data
        if len(name) > 255:
            response = generate_response(
                status=HTTPStatus.BAD_REQUEST,
                message='Name cannot exceed 255 characters.'
            )
            return response, HTTPStatus.BAD_REQUEST

        if email and len(email) > 255:
            response = generate_response(
                status=HTTPStatus.BAD_REQUEST,
                message='Email cannot exceed 255 characters.'
            )
            return response, HTTPStatus.BAD_REQUEST

        new_vendor = Vendor(
            name=name,
            email=email,
            is_active=data.get('is_active', True),
            is_default=data.get('is_default', False),
            created_at=datetime.utcnow(),
            modified_at=datetime.utcnow()
        )

        db.session.add(new_vendor)
        db.session.commit()

        response = generate_response(
            success=True,
            status=HTTPStatus.CREATED,
            message='Vendor created successfully.'
        )
        return response, HTTPStatus.CREATED

    except Exception as e:
        response = generate_response(
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
            message='An unexpected error occurred.',
            errors=str(e)
        )
        vendors.logger.error(f'Error creating vendor: {e}')
        return response, HTTPStatus.INTERNAL_SERVER_ERROR
    

@vendors.route('/all_vendors', methods=['GET'])
@jwt_required()
def get_vendors():
    response = generate_response()
    try:
        current_user = get_jwt_identity()
        if not current_user:
            response = generate_response(
                status=HTTPStatus.UNAUTHORIZED,
                message='Authentication required.'
            )
            return response, HTTPStatus.UNAUTHORIZED
        
        # Check if the current user has an admin role
        user_role = current_user.get('role')
        if user_role != 'admin':
            response = generate_response(
                status=HTTPStatus.FORBIDDEN,
                message='You do not have permission to access this resource.'
            )
            return response, HTTPStatus.FORBIDDEN

        vendors = Vendor.query.all()
        
        if not vendors:
            response = generate_response(
                status=HTTPStatus.NOT_FOUND,
                message='No vendors found.'
            )
            return response, HTTPStatus.NOT_FOUND

        vendor_list = []
        for vendor in vendors:
            vendor_data = {
                'id': vendor.id,
                'name': vendor.name,
                'email': vendor.email,
                'is_active': vendor.is_active,
                'is_default': vendor.is_default,
                'created_at': vendor.created_at,
                'modified_at': vendor.modified_at
            }
            vendor_list.append(vendor_data)

        response = generate_response(
            success=True,
            status=HTTPStatus.OK,
            message='Vendors retrieved successfully.',
            data=vendor_list
        )
        return response, HTTPStatus.OK

    except Exception as e:
        response = generate_response(
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
            message='An error occurred while fetching vendors.',
            errors=str(e)
        )
        vendors.logger.error(f'Error fetching vendors: {e}')
        return response, HTTPStatus.INTERNAL_SERVER_ERROR


@vendors.route('/vendor_id/<int:id>', methods=['GET'])
@jwt_required()
def get_vendor_by_id(id):
    response = generate_response()
    try:
        current_user = get_jwt_identity()
        
        if not current_user:
            response = generate_response(
                status=HTTPStatus.UNAUTHORIZED,
                message='Authentication required.'
            )
            return response, HTTPStatus.UNAUTHORIZED
        

        # Check if the current user has an admin role
        user_role = current_user.get('role')
        if user_role != 'admin':
            response = generate_response(
                status=HTTPStatus.FORBIDDEN,
                message='You do not have permission to access this resource.'
            )
            return response, HTTPStatus.FORBIDDEN
        
        vendor = Vendor.query.get(id)
        if not vendor:
            response = generate_response(
                status=HTTPStatus.NOT_FOUND,
                message='Vendor not found.'
            )
            return response, HTTPStatus.NOT_FOUND

        vendor_data = {
            'id': vendor.id,
            'name': vendor.name,
            'email': vendor.email,
            'is_active': vendor.is_active,
            'is_default': vendor.is_default,
            'created_at': vendor.created_at,
            'modified_at': vendor.modified_at
        }

        response = generate_response(
            success=True,
            status=HTTPStatus.OK,
            message='Vendor retrieved successfully.',
            data=vendor_data
        )
        return response, HTTPStatus.OK

    except Exception as e:
        response = generate_response(
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
            message='An unexpected error occurred.',
            errors=str(e)
        )
        vendors.logger.error(f'Error fetching vendor by id {id}: {e}')
        return response, HTTPStatus.INTERNAL_SERVER_ERROR


@vendors.route('/update_vendor/<int:id>', methods=['PUT'])
@jwt_required()
def update_vendor(id):
    response = generate_response()
    try:
        current_user = get_jwt_identity()
        
        if not current_user:
            response = generate_response(
                status=HTTPStatus.UNAUTHORIZED,
                message='Authentication required.'
            )
            return response, HTTPStatus.UNAUTHORIZED
        
        # Check if the current user has an admin role
        user_role = current_user.get('role')
        if user_role != 'admin':
            response = generate_response(
                status=HTTPStatus.FORBIDDEN,
                message='You do not have permission to access this resource.'
            )
            return response, HTTPStatus.FORBIDDEN
        
        vendor = Vendor.query.get(id)
        if not vendor:
            response = generate_response(
                status=HTTPStatus.NOT_FOUND,
                message='Vendor not found.'
            )
            return response, HTTPStatus.NOT_FOUND

        data = request.get_json()

        if not data or not any(field in data for field in ['name', 'email', 'is_active', 'is_default']):
            response = generate_response(
                status=HTTPStatus.BAD_REQUEST,
                message='No fields to update provided.'
            )
            return response, HTTPStatus.BAD_REQUEST

        if 'name' in data:
            if not isinstance(data['name'], str) or not data['name']:
                response = generate_response(
                    status=HTTPStatus.BAD_REQUEST,
                    message='Invalid name.'
                )
                return response, HTTPStatus.BAD_REQUEST
            vendor.name = data['name']
        
        if 'email' in data:
            email = data['email']
            if email and (not isinstance(email, str) or '@' not in email):
                response = generate_response(
                    status=HTTPStatus.BAD_REQUEST,
                    message='Invalid email.'
                )
                return response, HTTPStatus.BAD_REQUEST
            vendor.email = email
        
        if 'is_active' in data:
            if not isinstance(data['is_active'], bool):
                response = generate_response(
                    status=HTTPStatus.BAD_REQUEST,
                    message='Invalid value for is_active.'
                )
                return response, HTTPStatus.BAD_REQUEST
            vendor.is_active = data['is_active']
        
        if 'is_default' in data:
            if not isinstance(data['is_default'], bool):
                response = generate_response(
                    status=HTTPStatus.BAD_REQUEST,
                    message='Invalid value for is_default.'
                )
                return response, HTTPStatus.BAD_REQUEST
            vendor.is_default = data['is_default']

        vendor.modified_at = datetime.utcnow()

        try:
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            response = generate_response(
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
                message='Database error.',
                errors=str(e)
            )
            return response, HTTPStatus.INTERNAL_SERVER_ERROR

        vendor_data = {
            'id': vendor.id,
            'name': vendor.name,
            'email': vendor.email,
            'is_active': vendor.is_active,
            'is_default': vendor.is_default,
            'created_at': vendor.created_at,
            'modified_at': vendor.modified_at
        }

        response = generate_response(
            success=True,
            status=HTTPStatus.OK,
            message='Vendor updated successfully.'
        )
        return response, HTTPStatus.OK

    except Exception as e:
        response = generate_response(
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
            message='An unexpected error occurred.',
            errors=str(e)
        )
        vendors.logger.error(f'Error updating vendor with id {id}: {e}')
        return response, HTTPStatus.INTERNAL_SERVER_ERROR



@vendors.route('/delete_vendor/<int:id>', methods=['DELETE'])
@jwt_required()
def delete_vendor(id):
    response = generate_response()
    try:
        current_user = get_jwt_identity()
        
        if not current_user:
            response = generate_response(
                status=HTTPStatus.UNAUTHORIZED,
                message='Authentication required.'
            )
            return response, HTTPStatus.UNAUTHORIZED
        
        # Check if the current user has an admin role
        user_role = current_user.get('role')
        if user_role != 'admin':
            response = generate_response(
                status=HTTPStatus.FORBIDDEN,
                message='You do not have permission to access this resource.'
            )
            return response, HTTPStatus.FORBIDDEN
        
        vendor = Vendor.query.get(id)
        if not vendor:
            response = generate_response(
                status=HTTPStatus.NOT_FOUND,
                message='Vendor not found.'
            )
            return response, HTTPStatus.NOT_FOUND

        try:
            related_portfolios = Portfolio.query.filter_by(vendor_id=id).all()
            if related_portfolios:
                Portfolio.query.filter_by(vendor_id=id).delete()
                db.session.flush() 

            db.session.delete(vendor)
            db.session.commit()
            
        except Exception as e:
            db.session.rollback()
            response = generate_response(
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
                message='An error occurred while deleting the vendor.',
                errors=str(e)
            )
            return response, HTTPStatus.INTERNAL_SERVER_ERROR

        response = generate_response(
            success=True,
            status=HTTPStatus.OK,
            message=f'Vendor with id {id} has been deleted, along with related portfolios.'
        )
        return response, HTTPStatus.OK

    except Exception as e:
        response = generate_response(
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
            message='An unexpected error occurred.',
            errors=str(e)
        )
        vendors.logger.error(f'Error deleting vendor with id {id}: {e}')
        return response, HTTPStatus.INTERNAL_SERVER_ERROR
