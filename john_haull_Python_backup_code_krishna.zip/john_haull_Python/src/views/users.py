from flask import Blueprint, request, jsonify
from flask_login import login_user, current_user
from config import db, bcrypt
from src.models.users import User, UserProfile,TokenBlacklist
from src.views.forms import RegistrationForm, LoginForm ,ChangePasswordForm,UpdateUserForm
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity,get_jwt
from werkzeug.security import check_password_hash
from itsdangerous import URLSafeTimedSerializer
from flask import current_app, url_for
from flask_mail import Mail, Message
from config import mail
from datetime import datetime
from config import revoked_tokens
import logging
from http import HTTPStatus
from datetime import timedelta
from sqlalchemy.exc import SQLAlchemyError
from werkzeug.utils import secure_filename
from src.controller.users_controller import * 
users = Blueprint('users', __name__)

# Configure logging
logging.basicConfig(level=logging.INFO)



@users.route('/register', methods=['POST'])
def register():
    response = generate_response()
    try:
        data = request.get_json()
        form = RegistrationForm(data=data)

        if form.validate():
            existing_user = get_user_by_email(form.email.data)
            if existing_user:
                response = generate_response(
                    status=HTTPStatus.BAD_REQUEST,
                    message='User already exists.'
                )
                return response, HTTPStatus.BAD_REQUEST

            # Start a transaction
            try:
                # Create the user
                role = form.role.data if form.role.data else 'one time'
                user = create_user(form.email.data, form.password.data, role)
                
                if not user:
                    db.session.rollback()  # Rollback if user creation failed
                    response = generate_response(
                        status=HTTPStatus.INTERNAL_SERVER_ERROR,
                        message='An error occurred while creating the user.'
                    )
                    return response, HTTPStatus.INTERNAL_SERVER_ERROR

                # Check for profile image
                profile_image = form.profile_image.data if form.profile_image.data else media_path
                profile = create_user_profile(
                    user.id, 
                    form.first_name.data, 
                    form.last_name.data, 
                    form.contact_no.data, 
                    profile_image
                )
                
                if not profile:
                    db.session.rollback()  # Rollback if profile creation failed
                    response = generate_response(
                        status=HTTPStatus.INTERNAL_SERVER_ERROR,
                        message='An error occurred while creating the user profile.'
                    )
                    return response, HTTPStatus.INTERNAL_SERVER_ERROR

                db.session.commit()  # Commit the transaction if all operations succeed
                
                response = generate_response(
                    success=True,
                    status=HTTPStatus.CREATED,
                    message='Signup successful.'
                )
                return response, HTTPStatus.CREATED

            except SQLAlchemyError as e:
                db.session.rollback()  # Rollback if any SQLAlchemy error occurs
                response = generate_response(
                    status=HTTPStatus.INTERNAL_SERVER_ERROR,
                    message='An error occurred during registration.',
                    errors=str(e)
                )
                return response, HTTPStatus.INTERNAL_SERVER_ERROR
        else:
            response = generate_response(
                status=HTTPStatus.BAD_REQUEST,
                message='Validation failed.',
                errors=form.errors
            )
            return response, HTTPStatus.BAD_REQUEST
    except Exception as e:
        response = generate_response(
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
            message='An error occurred during registration.',
            errors=str(e)
        )
        return response, HTTPStatus.INTERNAL_SERVER_ERROR
    

@users.route('/login', methods=['POST'])
def login():
    response = generate_response()
    try:
        data = request.get_json()

        # Check if the request has the necessary fields
        if not data or 'email' not in data or 'password' not in data:
            response = generate_response(
                status=HTTPStatus.BAD_REQUEST,
                message='Missing required fields.'
            )
            return response, HTTPStatus.BAD_REQUEST

        # Validate email format
        if not validate_email_format(data.get('email')):
            response = generate_response(
                status=HTTPStatus.BAD_REQUEST,
                message='Invalid email format.'
            )
            return response, HTTPStatus.BAD_REQUEST

        form = LoginForm(data=data)
        if form.validate():
            user = get_user_by_email(form.email.data)
            if user and bcrypt.check_password_hash(user.password, form.password.data):
                # Create access token with 24-hour expiration
                access_token = create_access_token(
                    identity={'id': user.id, 'email': user.email, 'role': user.role},
                    expires_delta=timedelta(hours=24)  # Token expires in 24 hours
                )
                response = generate_response(
                    success=True,
                    status=HTTPStatus.OK,
                    data={'access_token': access_token},
                    message='Login successful.'
                )
                logging.info(f"User {user.email} logged in successfully.")
                return response, HTTPStatus.OK
            else:
                response = generate_response(
                    status=HTTPStatus.UNAUTHORIZED,
                    message='Login Unsuccessful. Please check email and password.'
                )
                logging.warning(f"Failed login attempt for email {form.email.data}.")
                return response, HTTPStatus.UNAUTHORIZED
        else:
            response = generate_response(
                status=HTTPStatus.BAD_REQUEST,
                message='Validation failed.',
                errors= form.errors
            )
            return response, HTTPStatus.BAD_REQUEST
    except Exception as e:
        response = generate_response(
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
            message='An error occurred during login.',
            errors= str(e)
        )
        logging.error(f"Exception occurred during login: {str(e)}")
        return response, HTTPStatus.INTERNAL_SERVER_ERROR
    
@users.route('/admin/view_users', methods=['GET'])
@jwt_required()
def view_all_users():
    response = generate_response()
    try:
        # Check if the current user is authenticated
        current_user = get_jwt_identity()
        if not current_user:
            response = generate_response(
                status=HTTPStatus.UNAUTHORIZED,
                message='Authentication required.'
            )
            return response, HTTPStatus.UNAUTHORIZED
        
        # Check if the current user has an admin role
        user_role = current_user.get('role')
        if user_role != 'admin':
            response = generate_response(
                status=HTTPStatus.FORBIDDEN,
                message='You do not have permission to access this resource.'
            )
            return response, HTTPStatus.FORBIDDEN
        
        # Fetch all users from the database
        users = UserProfile.query.all()
        if not users:
            response = generate_response(
                success=True,
                status=HTTPStatus.OK,
                message='No users found.',
                data=[]
            )
            logging.info('No users found in the database.')
            return response, HTTPStatus.OK
        
        user_list = [{
            'id': user.id,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'contact_no': user.contact_no,
            'profile_image': user.profile_image,
            'created_at': user.created_at,
            'modified_at': user.modified_at
        } for user in users]

        response = generate_response(
            success=True,
            status=HTTPStatus.OK,
            message='User details retrieved successfully.',
            data=user_list
        )
        logging.info(f'{len(user_list)} users retrieved successfully.')
        return response, HTTPStatus.OK

    except Exception as e:
        response = generate_response(
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
            message='An error occurred while retrieving user details.',
            errors=str(e)
        )
        logging.error(f"Exception occurred while retrieving user details: {str(e)}")
        return response, HTTPStatus.INTERNAL_SERVER_ERROR
    

@users.route('/view_user/<int:user_id>', methods=['GET'])
@jwt_required()
def view_user(user_id):
    response = generate_response()
    try:
        # Fetch the current user's identity from the JWT token
        current_user = get_jwt_identity()
        current_user_id = current_user.get('id')
        user_role = current_user.get('role')

        # Fetch the user details by ID
        user = get_user_profile_by_id(user_id)
        
        # Check if the user exists
        if not user:
            response = generate_response(
                status=HTTPStatus.NOT_FOUND,
                message='User not found.'
            )
            return response, HTTPStatus.NOT_FOUND
        
        # Check if the current user is an admin or if they are trying to access their own details
        if user_role == 'admin' or user_id == current_user_id:
            user_data = {
                'id': user.id,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'contact_no': user.contact_no,
                'profile_image': user.profile_image,
                'created_at': user.created_at,
                'modified_at': user.modified_at
            }
            response = generate_response(
                success=True,
                status=HTTPStatus.OK,
                message='User details retrieved successfully.',
                data=user_data
            )
            logging.info(f"User {current_user_id} accessed user details for user {user_id}.")
            return response, HTTPStatus.OK
        else:
            response = generate_response(
                status=HTTPStatus.FORBIDDEN,
                message='You do not have permission to access this resource.',
            )
            logging.warning(f"User {current_user_id} attempted to access user details for user {user_id} without permission.")
            return response, HTTPStatus.FORBIDDEN

    except Exception as e:
        response = generate_response(
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
            message='An error occurred while retrieving user details.',
            errors= str(e)
        )
        logging.error(f"Exception occurred while retrieving user details: {str(e)}")
        return response, HTTPStatus.INTERNAL_SERVER_ERROR
    


@users.route('/change_password', methods=['POST'])
@jwt_required()
def change_password():
    response = generate_response()
    try:
        data = request.get_json()
        
        # Check for missing data
        if not data or 'current_password' not in data or 'new_password' not in data:
            response = generate_response(
                status=HTTPStatus.BAD_REQUEST,
                message='Missing required fields.'
            )
            return response, HTTPStatus.BAD_REQUEST
        
        form = ChangePasswordForm(data=data)
        current_user_id = get_jwt_identity().get('id')

        if form.validate():
            user = get_user_by_id(current_user_id)
            if user and bcrypt.check_password_hash(user.password, form.current_password.data):
                # Validate new password strength
                if not validate_password_strength(form.new_password.data):
                    response = generate_response(
                        status=HTTPStatus.BAD_REQUEST,
                        message='New password does not meet strength requirements.'
                       
                    )
                    return response, HTTPStatus.BAD_REQUEST
                
                if update_user_password(user, form.new_password.data):
                    response = generate_response(
                        success=True,
                        status=HTTPStatus.OK,
                        message='Password changed successfully.'
                    )
                    logging.info(f"Password changed successfully for user {current_user_id}.")
                    return response, HTTPStatus.OK
                else:
                    response = generate_response(
                        status=HTTPStatus.INTERNAL_SERVER_ERROR,
                        message='An error occurred while updating the password.'
                    )
                    logging.error(f"Failed to update password for user {current_user_id}.")
                    return response, HTTPStatus.INTERNAL_SERVER_ERROR
            else:
                response = generate_response(
                    status=HTTPStatus.UNAUTHORIZED,
                    message='Current password is incorrect.'
                )
                logging.warning(f"Invalid current password attempt for user {current_user_id}.")
                return response, HTTPStatus.UNAUTHORIZED
        else:
            response = generate_response(
                status=HTTPStatus.BAD_REQUEST,
                message='Validation failed.',
                errors=form.errors
            )
            return response, HTTPStatus.BAD_REQUEST
    except Exception as e:
        response = generate_response(
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
            message='An error occurred during the password change process.',
            errors= str(e)
        )
        logging.error(f"Exception occurred during password change: {str(e)}")
        return response, HTTPStatus.INTERNAL_SERVER_ERROR


@users.route('/forgot_password', methods=['POST'])
def forgot_password():
    response = generate_response()
    try:
        data = request.get_json()
        email = data.get('email')

        # Validate email format
        if not validate_email_format(email):
            response = generate_response(
                status=HTTPStatus.BAD_REQUEST,
                message='Invalid email format.'
            )
            return response, HTTPStatus.BAD_REQUEST

        user = get_user_by_email(email)
        if user:
            s = URLSafeTimedSerializer(current_app.config['SECRET_KEY'])
            token = s.dumps(email, salt=current_app.config['SECURITY_PASSWORD_SALT'])
            reset_url = url_for('users.reset_password', token=token, _external=True)
            msg = Message("Password Reset Request", sender="sheetaljain756@gmail.com", recipients=[email])
            msg.body = f"To reset your password, click the following link: {reset_url}\n\nIf you did not make this request, simply ignore this email and no changes will be made."
            try:
                mail.send(msg)
                response = generate_response(
                    success=True,
                    status=HTTPStatus.OK,
                    message='If an account with that email exists, a password reset email has been sent.'
                )
                return response, HTTPStatus.OK
            except Exception as e:
                response = generate_response(
                    status=HTTPStatus.INTERNAL_SERVER_ERROR,
                    message='Failed to send email.',
                    errors= str(e)
                )
                return response, HTTPStatus.INTERNAL_SERVER_ERROR
        else:
            response = generate_response(
                status=HTTPStatus.NOT_FOUND,
                message='No account found with that email address.'
            )
            return response, HTTPStatus.NOT_FOUND
    except Exception as e:
        response = generate_response(
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
            message='An error occurred while processing your request.',
            errors= str(e)
        )
        return response, HTTPStatus.INTERNAL_SERVER_ERROR


@users.route('/reset_password/<token>', methods=['POST'])
def reset_password(token):
    response = generate_response()
    try:
        data = request.get_json()
        new_password = data.get('password')

        # Validate new password strength
        if not validate_password_strength(new_password):
            response = generate_response(
                status=HTTPStatus.BAD_REQUEST,
                message='Password does not meet strength requirements.'
            )
            return response, HTTPStatus.BAD_REQUEST

        s = URLSafeTimedSerializer(current_app.config['SECRET_KEY'])
        try:
            email = s.loads(token, salt=current_app.config['SECURITY_PASSWORD_SALT'], max_age=3600)
        except Exception as e:
            response = generate_response(
                status=HTTPStatus.BAD_REQUEST,
                message='The reset link is invalid or has expired.',
                errors= str(e)
            )
            return response, HTTPStatus.BAD_REQUEST

        user = get_user_by_email(email)
        if user:
            hashed_password = bcrypt.generate_password_hash(new_password).decode('utf-8')
            user.password = hashed_password
            db.session.commit()
            response = generate_response(
                success=True,
                status=HTTPStatus.OK,
                message='Your password has been updated!'
            )
            return response, HTTPStatus.OK
        else:
            response = generate_response(
                status=HTTPStatus.NOT_FOUND,
                message='User does not exist.'
            )
            return response, HTTPStatus.NOT_FOUND
    except Exception as e:
        response = generate_response(
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
            message='An error occurred during password reset.',
            errors= str(e)
        )
        return response, HTTPStatus.INTERNAL_SERVER_ERROR
    
   
@users.route('/update_user', methods=['PUT'])
@jwt_required()
def update_user():
    response = generate_response()
    try:
        current_user_id = get_jwt_identity().get('id')

        # Check if user profile exists
        user_profile = get_user_profile_by_id(current_user_id)
        if not user_profile:
            response = generate_response(
                status=HTTPStatus.NOT_FOUND,
                message='User profile not found.'
            )
            return response, HTTPStatus.NOT_FOUND
        
        form = UpdateUserForm()
        if form.validate_on_submit():
            # Handle profile image update if provided
            profile_image_file = request.files.get('profile_image')
            if profile_image_file:
                # Validate file type and size
                if not allowed_file(profile_image_file.filename):
                    response = generate_response(
                        status=HTTPStatus.BAD_REQUEST,
                        message='Invalid file type.'
                       
                    )
                    return response, HTTPStatus.BAD_REQUEST
                
                if len(profile_image_file.read()) > MAX_CONTENT_LENGTH:
                    response = generate_response(
                        status=HTTPStatus.BAD_REQUEST,
                        message='File size exceeds limit.'
                    )
                    return response, HTTPStatus.BAD_REQUEST
                
                profile_image_file.seek(0)  # Reset file pointer after size check
                profile_image_path = save_profile_image(profile_image_file)
                if not profile_image_path:
                    response = generate_response(
                        status=HTTPStatus.INTERNAL_SERVER_ERROR,
                        message='Failed to save profile image.'
                    )
                    return response, HTTPStatus.INTERNAL_SERVER_ERROR

            # Call the controller function to update the user
            update_success = update_user_details(current_user_id, form, request.files)
            if update_success:
                response = generate_response(
                    success=True,
                    status=HTTPStatus.OK,
                    message='User details updated successfully.'
                )
                return response, HTTPStatus.OK
            else:
                response = generate_response(
                    status=HTTPStatus.INTERNAL_SERVER_ERROR,
                    message='Failed to update user details.'
                )
                return response, HTTPStatus.INTERNAL_SERVER_ERROR
        else:
            response = generate_response(
                status=HTTPStatus.BAD_REQUEST,
                message='Validation failed.',
                errors=form.errors
            )
            return response, HTTPStatus.BAD_REQUEST
    except Exception as e:
        response = generate_response(
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
            message='An error occurred while updating user details.',
            errors= str(e)
        )
        return response, HTTPStatus.INTERNAL_SERVER_ERROR


@users.route('/update_profile_image', methods=['PUT'])
@jwt_required()
def update_profile_image():
    response = generate_response()
    try:
        current_user_id = get_jwt_identity().get('id')
        user_profile = get_user_profile_by_id(current_user_id)

        if user_profile:
            if 'profile_image' not in request.files:
                response = generate_response(
                    status=HTTPStatus.BAD_REQUEST,
                    message='No profile image provided.'
                )
                return response, HTTPStatus.BAD_REQUEST
            
            file = request.files['profile_image']

            if file.filename == '':
                response = generate_response(
                    status=HTTPStatus.BAD_REQUEST,
                    message='No file selected.'
                )
                return response, HTTPStatus.BAD_REQUEST
            
            if not allowed_file(file.filename):
                response = generate_response(
                    status=HTTPStatus.BAD_REQUEST,
                    message='Invalid file type.'
                )
                return response, HTTPStatus.BAD_REQUEST
            
            if file:
                if len(file.read()) > MAX_CONTENT_LENGTH:
                    response = generate_response(
                        status=HTTPStatus.BAD_REQUEST,
                        message='File size exceeds limit.'
                    )
                    return response, HTTPStatus.BAD_REQUEST
                
                file.seek(0)  # Reset file pointer after size check
                profile_image_path = save_profile_image(file)

                if not profile_image_path:
                    response = generate_response(
                        status=HTTPStatus.INTERNAL_SERVER_ERROR,
                        message='An error occurred while saving the profile image.'
                    )
                    return response, HTTPStatus.INTERNAL_SERVER_ERROR
                
                user_profile.profile_image = profile_image_path
                user_profile.modified_at = datetime.utcnow()
                
                try:
                    db.session.commit()
                except Exception as e:
                    db.session.rollback()
                    logging.error(f"Database commit failed: {str(e)}")
                    response = generate_response(
                        status=HTTPStatus.INTERNAL_SERVER_ERROR,
                        message='An error occurred while updating user profile.',
                        errors=str(e)
                    )
                    return response, HTTPStatus.INTERNAL_SERVER_ERROR

                logging.info(f"Profile image updated successfully for user {current_user_id}.")
                
                response = generate_response(
                    success=True,
                    status=HTTPStatus.OK,
                    message='Profile image updated successfully.'
                )
                return response, HTTPStatus.OK
        else:
            response = generate_response(
                status=HTTPStatus.NOT_FOUND,
                message='User profile not found.'
            )
            return response, HTTPStatus.NOT_FOUND

    except Exception as e:
        logging.error(f"Exception occurred while updating profile image: {str(e)}")
        response = generate_response(
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
            message='An error occurred while updating profile image.',
            errors= str(e)
        )
        return response, HTTPStatus.INTERNAL_SERVER_ERROR
    

@users.route('/delete_user/<int:user_id>', methods=['DELETE'])
@jwt_required()
def delete_user(user_id):
    response = generate_response()
    try:
        current_user_id = get_jwt_identity().get('id')
        current_user_role = get_jwt_identity().get('role')

        if current_user_role != 'admin' and current_user_id != user_id:
            response = generate_response(
                status=HTTPStatus.FORBIDDEN,
                message='Permission denied'
            )
            return response, HTTPStatus.FORBIDDEN

        user = User.query.get(user_id)
        if user:
            user_profile = UserProfile.query.filter_by(user_id=user_id).first()
            if user_profile:
                db.session.delete(user_profile)

            db.session.delete(user)
            db.session.commit()
            response = generate_response(
                success=True,
                status=HTTPStatus.OK,
                message='User deleted successfully'
            )
            return response, HTTPStatus.OK
        else:
            response = generate_response(
                status=HTTPStatus.NOT_FOUND,
                message='User not found'
            )
            return response, HTTPStatus.NOT_FOUND
    except Exception as e:
        response = generate_response(
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
            message='An error occurred during user deletion.',
            errors= str(e)
        )
        return response, HTTPStatus.INTERNAL_SERVER_ERROR


@users.route('/logout', methods=['DELETE'])
@jwt_required()
def logout():
    try:
        # Get the JWT ID (jti) from the current token
        jti = get_jwt()['jti']

        # Check if the token is already revoked
        if jti in revoked_tokens:
            response = generate_response(
                success=False,
                status=HTTPStatus.BAD_REQUEST,
                message='Token has already been revoked.'
            )
            return response, HTTPStatus.BAD_REQUEST

        # Add the token to the blacklist
        revoked_tokens.add(jti)
        logging.info(f"Token {jti} successfully added to blacklist.")

        response = generate_response(
            success=True,
            status=HTTPStatus.OK,
            message='Successfully logged out.'
        )
        return response, HTTPStatus.OK

    except Exception as e:
        logging.error(f"Exception occurred during logout: {str(e)}")
        response = generate_response(
            success=False,
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
            message='An error occurred while logging out.',
            errors= str(e)
        )
        return response, HTTPStatus.INTERNAL_SERVER_ERROR
