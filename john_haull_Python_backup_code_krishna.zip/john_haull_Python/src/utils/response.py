def generate_response(success=False, status='', data=None, message='', errors=None):
    if data is None:
        data = {}
    if errors is None:
        errors = {}

    return {
        'success': success,
        'status': status,
        'data': data,
        'message': message,
        'errors': errors
    }
