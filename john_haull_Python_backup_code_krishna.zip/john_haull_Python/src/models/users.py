from datetime import datetime
from flask_login import UserMixin

def get_db():
    from config import db 
    return db

class User(get_db().Model, UserMixin):
    __tablename__ = 'users'
    id = get_db().Column(get_db().Integer, primary_key=True)
    email = get_db().Column(get_db().String(120), unique=True, nullable=False)
    password = get_db().Column(get_db().String(60), nullable=False)
    role = get_db().Column(get_db().String(100), nullable=False)
    is_active = get_db().Column(get_db().Boolean, default=True)
    created_at = get_db().Column(get_db().DateTime, nullable=False, default=datetime.utcnow)
    modified_at = get_db().Column(get_db().DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = get_db().Column(get_db().DateTime, nullable=True)

    profile = get_db().relationship('UserProfile', backref='user', uselist=False)

class UserProfile(get_db().Model):
    __tablename__ = 'user_profile'
    id = get_db().Column(get_db().Integer, primary_key=True)
    user_id = get_db().Column(get_db().Integer, get_db().ForeignKey('users.id'), nullable=False)
    first_name = get_db().Column(get_db().String(100), nullable=False)
    last_name = get_db().Column(get_db().String(100), nullable=False)
    contact_no = get_db().Column(get_db().BigInteger, nullable=False)
    profile_image = get_db().Column(get_db().Text, nullable=True)
    created_at = get_db().Column(get_db().DateTime, nullable=False, default=datetime.utcnow)
    modified_at = get_db().Column(get_db().DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

class TokenBlacklist(get_db().Model):
    id = get_db().Column(get_db().Integer, primary_key=True)
    token = get_db().Column(get_db().String(255), unique=True, nullable=False)
    created_at = get_db().Column(get_db().DateTime, default=datetime.utcnow)
   

# class Vendor(get_db().Model):
#     __tablename__ = 'vendors'
#     id = get_db().Column(get_db().Integer, primary_key=True)
#     name = get_db().Column(get_db().String(255), nullable=False)
#     email = get_db().Column(get_db().String(255), nullable=True)
#     is_active = get_db().Column(get_db().Boolean, default=True)
#     is_default = get_db().Column(get_db().Boolean, default=False)
#     created_at = get_db().Column(get_db().DateTime, default=datetime.utcnow)
#     modified_at = get_db().Column(get_db().DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

# class Property(get_db().Model):
#     __tablename__ = 'properties'
#     id = get_db().Column(get_db().Integer, primary_key=True)
#     address = get_db().Column(get_db().String(255), nullable=True)
#     other_details_of_property = get_db().Column(get_db().String(255), nullable=False)
#     user_id = get_db().Column(get_db().Integer, get_db().ForeignKey('users.id'), nullable=False)
#     is_active = get_db().Column(get_db().Boolean, nullable=False, default=True)
#     is_open = get_db().Column(get_db().Boolean, default=False)
#     created_at = get_db().Column(get_db().DateTime, default=datetime.utcnow)
#     modified_at = get_db().Column(get_db().DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

# class Portfolio(get_db().Model):
#     __tablename__ = 'portfolio'
#     id = get_db().Column(get_db().Integer, primary_key=True)
#     user_id = get_db().Column(get_db().Integer, get_db().ForeignKey('users.id'), nullable=False)
#     vendor_id = get_db().Column(get_db().Integer, get_db().ForeignKey('vendors.id'), nullable=False)
#     property_id = get_db().Column(get_db().Integer, get_db().ForeignKey('properties.id'), nullable=False)
#     is_active = get_db().Column(get_db().Boolean, default=True)
#     created_at = get_db().Column(get_db().DateTime, default=datetime.utcnow)
#     modified_at = get_db().Column(get_db().DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

# class CombinedField(get_db().Model):
#     __tablename__ = 'combined_fields'
#     id = get_db().Column(get_db().Integer, primary_key=True)
#     field_name = get_db().Column(get_db().String(255), nullable=False)
#     vendor_id = get_db().Column(get_db().ARRAY(get_db().Integer), nullable=False)
#     is_active = get_db().Column(get_db().Boolean, default=True)
#     created_at = get_db().Column(get_db().DateTime, default=datetime.utcnow)
#     modified_at = get_db().Column(get_db().DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

# class UserFormField(get_db().Model):
#     __tablename__ = 'user_form_fields'
#     id = get_db().Column(get_db().Integer, primary_key=True)
#     user_id = get_db().Column(get_db().Integer, get_db().ForeignKey('users.id'), nullable=False)
#     field_id = get_db().Column(get_db().Integer, get_db().ForeignKey('combined_fields.id'), nullable=False)
#     property_id = get_db().Column(get_db().Integer, get_db().ForeignKey('properties.id'), nullable=False)
#     fields_value = get_db().Column(get_db().String(255))
#     created_at = get_db().Column(get_db().DateTime, default=datetime.utcnow)
#     modified_at = get_db().Column(get_db().DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

# class Payment(get_db().Model):
#     __tablename__ = 'payments'
#     id = get_db().Column(get_db().Integer, primary_key=True)
#     user_id = get_db().Column(get_db().Integer, get_db().ForeignKey('users.id'), nullable=False)
#     property_id = get_db().Column(get_db().Integer, get_db().ForeignKey('properties.id'), nullable=False)
#     amount = get_db().Column(get_db().Integer, nullable=False)
#     transaction_id = get_db().Column(get_db().BigInteger, nullable=False)
#     strip_status = get_db().Column(get_db().Boolean, default=False)
#     created_at = get_db().Column(get_db().DateTime, default=datetime.utcnow)
#     modified_at = get_db().Column(get_db().DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)