from datetime import datetime
from flask_login import UserMixin

def get_db():
    from config import db
    return db

class Vendor(get_db().Model):
    __tablename__ = 'vendors'
    id = get_db().Column(get_db().Integer, primary_key=True)
    name = get_db().Column(get_db().String(255), nullable=False)
    email = get_db().Column(get_db().String(255), nullable=True)
    is_active = get_db().Column(get_db().Boolean, default=True)
    is_default = get_db().Column(get_db().Boolean, default=False)
    created_at = get_db().Column(get_db().DateTime, default=datetime.utcnow)
    modified_at = get_db().Column(get_db().DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

