from datetime import datetime

def get_db():
    from config import db
    return db

class Property(get_db().Model):
    __tablename__ = 'properties'
    id = get_db().Column(get_db().Integer, primary_key=True)
    address = get_db().Column(get_db().String(255), nullable=True)
    user_id = get_db().Column(get_db().Integer, get_db().ForeignKey('users.id'), nullable=False)
    is_active = get_db().Column(get_db().Boolean, nullable=False, default=True)
    is_open = get_db().Column(get_db().Boolean, default=False)
    created_at = get_db().Column(get_db().DateTime, default=datetime.utcnow)
    modified_at = get_db().Column(get_db().DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Portfolio(get_db().Model):
    __tablename__ = 'portfolio'
    id = get_db().Column(get_db().Integer, primary_key=True)
    user_id = get_db().Column(get_db().Integer, get_db().ForeignKey('users.id'), nullable=False)
    vendor_id = get_db().Column(get_db().Integer, get_db().ForeignKey('vendors.id'), nullable=False)
    property_id = get_db().Column(get_db().Integer, get_db().ForeignKey('properties.id'), nullable=False)
    is_active = get_db().Column(get_db().Boolean, default=True)
    created_at = get_db().Column(get_db().DateTime, default=datetime.utcnow)
    modified_at = get_db().Column(get_db().DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

