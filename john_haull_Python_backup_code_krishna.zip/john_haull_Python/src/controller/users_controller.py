import os
import re
from werkzeug.utils import secure_filename
from datetime import datetime
from src.models.users import User, UserProfile
from config import db, bcrypt
from config.settings import Config
from dotenv import load_dotenv

load_dotenv()

# Configuration for file uploads
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
MAX_CONTENT_LENGTH = 2 * 1024 * 1024  # 2 MB limit

media_directory = os.getenv('MEDIA_PATH')
media_path = os.path.join(media_directory, 'profile_image','default.png')

def generate_response(success=False, status='', data=None, message='', errors=None):
    """
    Generate a standardized response format.
    """
    response = {
        'success': success,
        'status': status,
        'message': message,
    }

    if data is not None:
        response['data'] = data

    if errors:
        response['errors'] = errors

    return response


def validate_email_format(email):
    """
    Validate the format of an email address using a regular expression.
    """
    email_regex = re.compile(
        r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)"
    )
    return bool(email_regex.match(email))

def validate_password_strength(password):
    """
    Validate password strength requirements.
    """
    if len(password) < 8:
        return False
    if not re.search(r'[A-Za-z]', password):
        return False
    if not re.search(r'[0-9]', password):
        return False
    if not re.search(r'[@$!%*?&]', password):
        return False
    return True

def create_user(email, password, role='one time'):
    """
    Create a new user and store it in the database.
    """
    try:
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        user = User(
            email=email,
            password=hashed_password,
            role=role,
            is_active=True,
            created_at=datetime.utcnow(),
            modified_at=datetime.utcnow(),
            created_by=None
        )

        db.session.add(user)
        db.session.commit()
        return user
    except Exception as e:
        print(f"Error occurred while creating the user: {e}")
        db.session.rollback()
        return None

def create_user_profile(user_id, first_name, last_name, contact_no, profile_image):
    """
    Create a user profile and store it in the database.
    """
    try:
        profile = UserProfile(
            user_id=user_id,
            first_name=first_name,
            last_name=last_name,
            contact_no=contact_no,
            profile_image=profile_image
        )
        db.session.add(profile)
        db.session.commit()
        return profile
    except Exception as e:
        print(f"Error occurred while creating the user profile: {e}")
        db.session.rollback()
        return None

def get_user_by_email(email):
    """
    Retrieve a user from the database by email.
    """
    try:
        user = User.query.filter_by(email=email).first()
        return user
    except Exception as e:
        print(f"Error occurred while querying the user: {e}")
        return None

def get_user_by_id(user_id):
    """
    Retrieve a user from the database by ID.
    """
    try:
        user = User.query.get(user_id)
        return user
    except Exception as e:
        print(f"Error occurred while querying the user by ID: {e}")
        return None

def get_user_profile_by_id(user_id):
    """
    Retrieve a user profile from the database by user ID.
    """
    try:
        profile = UserProfile.query.get(user_id)
        return profile
    except Exception as e:
        print(f"Error occurred while querying the user profile by ID: {e}")
        return None

def update_user_password(user, new_password):
    """
    Update the password for a user.
    """
    try:
        hashed_password = bcrypt.generate_password_hash(new_password).decode('utf-8')
        user.password = hashed_password
        db.session.commit()
        return True
    except Exception as e:
        print(f"Error occurred while updating the password: {e}")
        db.session.rollback()
        return False

def update_user_details(user_id, form, files):
    """
    Update user details based on form data and files.
    """
    try:
        user = get_user_by_id(user_id)
        user_profile = get_user_profile_by_id(user_id)
        if user and user_profile:
            # Update User fields
            if form.first_name.data:
                user_profile.first_name = form.first_name.data
            if form.last_name.data:
                user_profile.last_name = form.last_name.data
            if form.contact_no.data:
                user_profile.contact_no = form.contact_no.data

            user.modified_at = datetime.utcnow()
            user_profile.modified_at = datetime.utcnow()

            db.session.commit()
            return True
        else:
            return False
    except Exception as e:
        print(f"Error occurred while updating user details: {e}")
        db.session.rollback()
        return False

def save_profile_image(file):
    """
    Save the uploaded profile image file and return the file path.
    """
    # Define the upload folder
    upload_folder = os.path.join(media_directory, 'profile_image')

    # Ensure the directory exists
    if not os.path.exists(upload_folder):
        os.makedirs(upload_folder)
    
    # Secure the filename and create the file path
    filename = secure_filename(file.filename)
    filepath = os.path.join(upload_folder, filename)
    
    # Save the file
    try:
        file.save(filepath)
        return filepath
    except Exception as e:
        print(f"Failed to save file {filename}: {str(e)}")
        return None

def allowed_file(filename):
    """
    Check if the file extension is allowed.
    """
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
